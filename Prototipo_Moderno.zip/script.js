
function goToDashboard() {
    document.getElementById("login-screen").style.display = "none";
    document.getElementById("patient-screen").style.display = "none";
    document.getElementById("dashboard-screen").style.display = "flex";
}

function goToPatient() {
    document.getElementById("dashboard-screen").style.display = "none";
    document.getElementById("patient-screen").style.display = "flex";
}
